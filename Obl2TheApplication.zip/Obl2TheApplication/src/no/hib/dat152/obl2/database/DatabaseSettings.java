package no.hib.dat152.obl2.database;

public class DatabaseSettings {
  static final String source = "java:comp/env/jdbc/DAT152"; 
}
